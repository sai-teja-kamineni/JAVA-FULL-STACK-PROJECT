package students;

public class Student {

}
