package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.model.UserPrincipal;
import com.example.demo.model.Users;
import com.example.demo.repository.UserRepo;

@Service
public class MyUserDetailsService implements UserDetailsService{
     @Autowired
     UserRepo repo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException { //UserDetails is a interface so you can't return that type object directly
		// TODO Auto-generated method stub
		Users u=repo.findByUsername(username);
		if(u==null) {
			System.out.println("no uname");
			throw new  UsernameNotFoundException("username not found");
		}
		return new UserPrincipal(u);
	}

}
