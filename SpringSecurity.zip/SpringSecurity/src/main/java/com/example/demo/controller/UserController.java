package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Users;
import com.example.demo.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService us;
	@PostMapping("/add")
	public Users adduser(@RequestBody Users user) {
		us.adduser(user);
		return user;
	}
	@PostMapping("/login")
	public String login(@RequestBody Users user) {
		return us.verify(user);
	}

}
