package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties.Authentication;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.Users;
import com.example.demo.repository.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo ur;
	@Autowired
	AuthenticationManager authmanager;
	@Autowired
	JWTService js;
	private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12); //Using to create object for  BCryptPasswordEncoder to encode the password
	
	public void  adduser(Users u) {
		u.setPassword(encoder.encode(u.getPassword()));
		ur.save(u);
	}

	public String verify(Users user) {
		org.springframework.security.core.Authentication authentication=authmanager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),user.getPassword()));
		if(authentication.isAuthenticated()) {
			return js.generateToken(user.getUsername());
		}
		return "fail";
	}

	

}
