package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.demo.service.MyUserDetailsService;

@Configuration     //Telling spring this is configuration file
@EnableWebSecurity	//Telling spring this is my customized security execute this file instead of default one
public class SecurityConfig {
	@Autowired
	private MyUserDetailsService user;
	@Autowired
	private JwtFilter jwtFilter;
	
	@Bean
	public SecurityFilterChain security(HttpSecurity http) throws Exception{
		http.csrf(customizer -> customizer.disable()); //Disables CSRF 
		http.authorizeHttpRequests(requests->requests.requestMatchers("add","login").permitAll().anyRequest().authenticated());//Enables authentication for every request received except for add,login urls.
		//http.formLogin(Customizer.withDefaults()); // Enabling form login for every request
		http.httpBasic(Customizer.withDefaults());  //Enabling basic auth in post man
		http.sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));// changes session to stateless
		//don't works well in browser like making into stateless
		http.addFilterBefore(jwtFilter,UsernamePasswordAuthenticationFilter.class); //Here we are adding our customized filter jwtfilter before usernamepasswordauthenticationfilter
		return http.build()
;		
	}
	
	@Bean             //This method validates the data from database we are implementing our own AuthenticationProvider
	public AuthenticationProvider authenticationprovider()//AuthenticationProvider is a interface so we can't create object for it
	{
		DaoAuthenticationProvider dao=new DaoAuthenticationProvider();//DAOAuthentication is a class which implements AuthenticationProvider interface  So we can customize authenticationprovider by using this object useful for database accesss
		dao.setPasswordEncoder(new BCryptPasswordEncoder(12));//use the Bcrypt password encoder as an encoder for password validation.If the user enters the password verify it by BcryptPasswordEncoder  
		dao.setUserDetailsService(user);
		return dao;   
	}
	@Bean
	public AuthenticationManager authenticationmanager(AuthenticationConfiguration config)throws Exception{
		return config.getAuthenticationManager();
	}
}
