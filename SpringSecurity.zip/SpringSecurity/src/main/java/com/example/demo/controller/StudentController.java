package com.example.demo.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class StudentController {
	private ArrayList<Student>students=new ArrayList<>();
	
	public StudentController() {
	
	Student s1=new Student(1,"sai",23);
	Student s2=new Student(2,"nits",24);
	students.add(s1);
	students.add(s2);}
	
	@GetMapping("/students")
	public List<Student> getStudents()
	{	
		return students;
	}
	@PostMapping("/addStudent")
	public Student add(@RequestBody Student s) {
		students.add(s);
		return s;
	}
	
	@GetMapping("/csrf-token")
	public CsrfToken get(HttpServletRequest request) {
		return (CsrfToken)request.getAttribute("_csrf");
	}
	

}
