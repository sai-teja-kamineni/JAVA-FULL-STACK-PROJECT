package com.klu.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klu.demo.model.sentmessage;


public interface sentmessageRepository extends JpaRepository<sentmessage,String>{

}
