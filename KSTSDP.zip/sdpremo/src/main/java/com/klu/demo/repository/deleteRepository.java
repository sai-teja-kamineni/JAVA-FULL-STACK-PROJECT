package com.klu.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klu.demo.model.delete;

public interface deleteRepository extends JpaRepository<delete,String>{

}
